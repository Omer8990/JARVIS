#!/bin/bash
sudo systemctl stop jarvis
echo "Jarvis stopped"
